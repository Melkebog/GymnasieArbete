<?php
    function emptyInputSignup($uid, $email, $pwd, $pwdrepeat){
		$result;
		if(empty($uid) || empty($email) || empty($pwd) || empty($pwdrepeat)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result;
	}
	
	function invalidUid($uid){
		$result;
		if (!preg_match("/^[a-zA-Z0-9]*$/", $uid)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result;
	}
	
	function invalidEmail($email){
		$result;
		if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result;
	}
	
	function pwdMatch($pwd, $pwdrepeat){
		$result;
		if($pwd !== $pwdrepeat){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result;
	}
	
	function uidExists($conn, $uid, $email){
		$sql = "SELECT * FROM users WHERE users_uid = ? OR users_email = ?;";
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt, $sql)){
			header("location: ../index.php?error=stmtfailed");
		    exit();
		}
		
		mysqli_stmt_bind_param($stmt, "ss", $uid, $email);
		mysqli_stmt_execute($stmt);
		
		$resultData = mysqli_stmt_get_result($stmt);
		
		if($row = mysqli_fetch_assoc($resultData)){
			return $row;
		}
		else{
			$result = false;
			return $result;
		}
		
		mysqli_stmt_close($stmt);
	}
	
		function createUser($conn, $uid, $email, $pwd){
		$sql = "INSERT INTO users (users_uid, users_pwd, users_email) VALUES (?, ?, ?);";
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt, $sql)){
			header("location: ../index.php?error=stmtfailed");
		    exit();
		}
		
		$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
		
		mysqli_stmt_bind_param($stmt, "sss", $uid, $hashedPwd, $email);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_close($stmt);
		header("location: ../index.php?error=none");
		exit();
	}
	
	function emptyInputLogin($name, $password){
		$result;
		if(empty($name) || empty($password)){
			$result = true;
		}
		else{
			$result = false;
		}
		return $result;
	}
	
	function loginUser($conn, $name, $password){
		$uidExists = uidExists($conn, $name, $name);
		
		if ($uidExists === false){
			header("location: ../index.php?error=WrongLogin");
		    exit();
		}
		
		$pwdHashed = $uidExists["users_pwd"];
		$checkPwd = password_verify($password, $pwdHashed);
		
		if ($checkPwd === false){
			header("location: ../index.php?error=WrongLogin");
		    exit();
		}
		else if($checkPwd === true){
			session_start();
			
			$_SESSION["userid"] = $uidExists["users_id"];
			$_SESSION["useruid"] = $uidExists["users_uid"];
			$_SESSION["useremail"] = $uidExists["users_email"];
			header("location: ../index.php");
		    exit();
		}
	}