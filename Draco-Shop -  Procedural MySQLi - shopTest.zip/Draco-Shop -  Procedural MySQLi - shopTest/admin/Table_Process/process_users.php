<?php


    $mysqli = new mysqli('localhost', 'root', '', 'drako-shopdb') or die(mysqli_error($mysqli));
	$id = 0;
	$update = false;
	$users_uid = '';
	$users_pwd = '';
	$users_email = '';
	
	if(isset($_POST['save']) && isset($_FILES['bild'])){
	   $users_uid = mysqli_real_escape_string($mysqli, $_POST['users_uid']);
	   $users_pwd = mysqli_real_escape_string($mysqli, $_POST['users_pwd']);
	   $users_email = mysqli_real_escape_string($mysqli, $_POST['users_email']);
	   
	   $hash = password_hash($users_pwd, PASSWORD_DEFAULT);
	   
	   $mysqli->query("INSERT INTO products (users_uid, users_pwd, users_email) VALUES('$users_uid', '$price', '$hash')") or
	       die($mysqli->error);
	    
	   $_SESSION['message'] = "Record has been saved!";
	   $_SESSION['msg_type'] = "Sucess";
	   
	   header("location: ../Data_tables/UsersAccountTable.php");

	}
	
   
	
	
	
	
	if (isset($_GET['delete'])){
		$id = $_GET['delete'];
		$res = $mysqli->query("select bild FROM products WHERE id=$id") or die($mysqli->error());
		$r = $res->fetch_array();
		$path = '../Images/'.$r[0];
		unlink($path);
	    $mysqli->query("DELETE FROM products WHERE id=$id") or die($mysqli->error());
		
	   $_SESSION['message'] = "Record has been Deleted!";
	   $_SESSION['msg_type'] = "Danger";
	   
	   
	   header("location: ../Data_tables/TableforproductEditor.PHP");
	}
	
	if (isset($_GET['edit'])){
		$id = $_GET['edit'];
		$update = true;
		$result = $mysqli->query("SELECT * FROM products WHERE id=$id") or die($mysqli->error());
		
			$row = $result->fetch_array();
			$title = $row['title'];
			$price = $row['price'];
			$description = $row['description'];
			$bild = $row['bild'];
		
	}
	
	if (isset($_POST['update'])){
		$id = mysqli_real_escape_string($mysqli, $_POST['id']);
		$title = mysqli_real_escape_string($mysqli, $_POST['title']);
		$price = mysqli_real_escape_string($mysqli, $_POST['price']);
		$description = mysqli_real_escape_string($mysqli, $_POST['description']);
		$bild = mysqli_real_escape_string($mysqli, $_POST['bild']);
		
		$mysqli->query("UPDATE products SET title='$name', price='$price', description='$description', 
		bild='$bild' WHERE id='$id'") or die($mysqli->error);
		
		$_SESSION['message'] = "Record has been Updated!";
		$_SESSION['msg_type'] = "warning";
		
		header("location: ../Data_tables/TableforproductEditor.PHP");
	}
?>