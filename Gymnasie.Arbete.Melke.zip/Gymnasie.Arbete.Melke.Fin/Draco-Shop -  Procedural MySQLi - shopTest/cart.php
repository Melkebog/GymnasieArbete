<?php
   include 'DBhandler.background.php';
   session_start();
?>

<!DOCTYPE html>
<html>
<head>
       <meta name="viewport" content="with=device-width, initial-scale=1.0">
	   <meta charset="utf-8" />      
	   <title>Draco Store</title>
	   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <link rel="stylesheet" href="style.css" />
	   <link rel="preconnect" href="https://fonts.googleapis.com">
       <link rel="preconnect" href="https://fonts.gstatic.com">
       <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	   <script src="https://kit.fontawesome.com/14cfa882fd.js" crossorigin="anonymous"></script>
</head> 
<body class="overlay"> 
		<!-------Login User-------->
		<div class="container">
			<?php include "Login_stuff.inc.php"; 
			?>
	    </div>
    
	
	<div class="container">
		<div class="row table-responsive table-responsive-xl justify-content-center">
			<div class="col-lgl-10">
				<?php 
					if(!isset($_SESSION["useruid"])){
					echo '<div class="alert alert-primary text-center mt-3" role="alert">
					You must Login to checkout!
					</div>';
					}
					?>
				<div style="display:<?php if(isset($_SESSION['showAlert'])){echo $_SESSION['showAlert'];}else{echo 'none'; }unset($_SESSION['showAlert']); ?>" class="alert alert-danger alert-dismissible mt-3">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
				<strong><?php if(isset($_SESSION['message'])){echo $_SESSION['message'];}unset($_SESSION['showAlert']); ?></strong>
				</div>
				<div class="table-responsive mt-3">
					<table class="table table-bordered table-striped text-center">
						<thead>
						  <tr>
							<td colspan="7">
								<h4 class="text-center text-white m-0">Products in your cart</h4>
							</td>
						  </tr>
						  <tr>
							<th>ID</th>
							<th>Image</th>
							<th>Name</th>
							<th>Price</th>
							<th>Quantity</th>
							<th>TotalPrice</th>
						 <th>
						  <a href="action.php?clear=all" class="badge-danger badge p-2" onclick="return confirm('Are you sure, you want to clear cart?');"><i class="fas fa-trash"></i>&nbsp;&nbsp;Clear cart</a>
						 </th>
							</tr>
						</thead>
						<tbody>
						 <?php
							require 'config.php';
							$stmt = $conn->prepare("SELECT * FROM cart");
							$stmt->execute();
							$result = $stmt->get_result();
							$grand_total = 0;
							while($row = $result->fetch_assoc()):
						 ?>
						 <tr>
							<td><?= $row['id'] ?></td>
							<input type="hidden" class="pid" value="<?= $row['id'] ?>">
							<td id="rezise"><img src="images/<?= $row['product_image'] ?>"></td>
							<td><?= $row['product_name'] ?></td>
							<td>$&nbsp;<?= number_format($row['product_price'],2); ?></td>
							<input type="hidden" class="pprice" value="<?= $row['product_price'] ?>">
							<td><input type="number" min="1" max="50" class="form-control itemQty" value="<?= $row['qty'] ?>" style="width:70px;"></td>
							<td>$&nbsp;<?= number_format($row['total_price'],2); ?></td>
							<td>
								<a href="action.php?remove=<?= $row['id'] ?>" class="text-danger lead" onclick="return confirm('Are you want to remove This item?');"><i class="fas fa-trash-alt fa-2x"></i></a>
							</td>
						 </tr>
							<?php $grand_total +=$row['total_price']; ?>
							<?php endwhile; ?>
							<tr>
								<td colspan="3">
									<a href="index.php" class="btn btn-success"><i class="fas fa-cart-plus"></i>&nbsp;&nbsp;Continue&nbsp;Shopping</a>
								</td>
								<td colspan="2"><b>Grand Total</b></td>
								<td><b>$&nbsp;<?= number_format($grand_total,2); ?></b></td>
								<td>
									<a href="checkout.php" class="btn btn-info <?= ($grand_total>1)?'':'disabled'; ?> <?= isset($_SESSION["useruid"])?'':'disabled'; ?>"><i class="far fa-credit-card">&nbsp;&nbsp;Checkout</i></a>
								</td>
							</tr>
						</tbody>
					</table>											
				</div>
			</div>
		</div>
	</div>

	  
    <!-------js-------->
   <script src="js/toggle.js"></script>
   <script src="js/ClickfuctionforLog.js"></script>
   <script src="js/SenddatatoCart.js"></script>
</body>
</html> 
