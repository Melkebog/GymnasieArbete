
<?php include "Securitymeasures.php";?>
<!DOCTYPE html>
<html>
<head>
       <meta charset="utf-8" />                                                                               
	   <title>Order list</title>
	  <script src="https://code.jquery.com/jquery-2.1.3.min.js" integrity="sha256-ivk71nXhz9nsyFDoYoGf2sbjrR9ddh+XDkCcfZxjvcM="
	  crossorigin="anonymous"></script>
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" 
	   integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" 
	   crossorigin="anonymous">
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
	   integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
       crossorigin="anonymous"></script>
       <link rel="stylesheet" href="../Admin_css/Headerforadmin.css" />
	   
</head>
  
<body>
 
    <?php require_once '../Table_Process/process_orders.php';?>
	
	<?php require_once 'EditorHeader.php';?>
    <?php 
	
	if (isset($_SESSION['message'])): ?>

    <div class="alert alert-<?=$_SESSION['msg_type']?>">
 	    <?php
		    echo $_SESSION['message'];
			unset($_SESSION['message']);
		?>
	</div>
	<?php endif; ?>
	<div class="container">
	<?php
	    $mysqli = new mysqli('localhost', 'root', '', 'drako-shopdb') or die(mysqli_error($mysqli));
		$result = $mysqli->query("SELECT * FROM orders") or die($mysqli->error);
		//pre_r($result);
	?>	
	
	<div class="row justify-content-center">
	   <table class="table">
	       <thead>
		      <tr>
			     <th>Name</th>
				 <th>email</th>
				 <th>phone</th>
				 <th>address</th>
				 <th>Payment&nbsp;method</th>
				 <th>products</th>
				 <th>Total&nbsp;paid</th>
				 <th colspan="2">Action</th>
			  </tr>
		   </thead>
	<?php
	   while ($row = $result->fetch_assoc()):?>
		   <tr>
		       <td><?php echo $row['name']; ?></td>
			   <td><?php echo $row['email']; ?></td>
			   <td><?php echo $row['phone']; ?></td>
			   <td><?php echo $row['address']; ?></td>
			   <td><?php echo $row['paymentMode']; ?></td>
			   <td><?php echo $row['products']; ?></td>
			   <td><?php echo $row['amount_paid']; ?></td>
			   <td>
				   <a href="Admintable.php?Print=<?php echo $row['id'];?>"
				      class="btn btn-info">Print</a>
				   <a href="../Table_Process/process_admin.php?delete=<?php echo $row['id'];?>"
				      class="btn btn-danger">Confirm</a>
			   </td>
		   </tr>
	<?php endwhile; ?>	   
	   </table>
	</div>
	<?php
		function pre_r($array){
			echo '<pre>';
			print_r($array);
			echo '</pre>';
		}
	?>
	
    
	</div>
</body>
</html> 