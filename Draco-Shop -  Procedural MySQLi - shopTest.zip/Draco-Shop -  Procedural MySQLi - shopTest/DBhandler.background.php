
<!--Behöver ändra namn om man inte använder local host xamp. only change if used for online server-->
<?php
   $dbServername = "localhost";
   $dbUsername = "root";
   $dbPassword = "";
   $dbName = "drako-shopdb";
   
   $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>