<?php
  $conn = new mysqli("localhost","root","","drako-shopdb");
  if($conn->connect_error){
   die("Connection Failed!".$conn->connect_error);
}
?>