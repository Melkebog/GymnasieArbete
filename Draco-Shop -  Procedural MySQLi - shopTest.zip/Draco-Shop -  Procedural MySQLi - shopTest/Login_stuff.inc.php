<div class="UserLogForm">
		  <div class="Register" style="display:none">
		   <form action="includes/signup.inc.php" method="post">
			   <label id="Regid"><h2>Register</h2></label></br>
			   <label>Input User Name</label></br>
		       <input type="text" name="uid"></br>
		       <label>Input a Email</label></br>
		       <input type="text" name="email"></br>
	           <label>Input password</label></br>
		       <input type="password" name="pwd"></br>
			   <label>Repeat password</label></br>
		       <input type="password" name="pwdrepeat"></br>
	           <button class="buttonchange" type="submit" name="submit">Sign Up</button>
			   <button class="BacktoLogin buttonchange" type="button">Back</button>
		  </form>
		 </div>
		 <div class="Login" style="display:none">
		   <form action="includes/login.inc.php" method="post">
		    <label id="Regid"><h2>Login</h2></label></br>
		    <label>Email or name</label></br>
		    <input type="text" name="name"></br>
	        <label>Password</label></br>
		    <input type="password" name="password"></br>
	        <button class="buttonchange" type="submit" name="submit">Login</button>
			<button class="BacktoRegist buttonchange" type="button">Back</button>
	      </form>
		 </div>
		</div>
		<?php
		  if(isset($_SESSION["useruid"]))
		  {
		?>
				
			   <div class='design_Name'><h1> <i class='fas fa-user' style='color: white'></i><?php echo " ".$_SESSION["useruid"];?><h1></div>
			  <button class="Buttonlogout"><a href='includes/logout.inc.php'>Logout</a></button>

		<?php
		  }
		  else{
		?>
		    <div class="RegAndLogBTN">
		    <input class="BTNChangeLog buttonchange" type="button" value="Login">
		    <input class="BTNChangeReg buttonchange" type="button" value="Register">
		    </div>
		  <?php
		  } 
		   ?>
		   <?php
			    if(isset($_GET["error"])){
					if($_GET["error"] == "emptyinput"){
						echo "<p>Fill in all fields!</p>";
					}
					else if($_GET["error"] == "invalidUid"){
						echo "<p>Choose a proper username!</p>";
					}
					else if($_GET["error"] == "WrongLogin"){
						echo "<p>Incorrect Login information!</p>";
					}
					else if($_GET["error"] == "emptyinput"){
						echo "<p>Fill in all fields!</p>";
					}
					else if($_GET["error"] == "invalidUid"){
						echo "<p>Choose a proper username!</p>";
					}
					else if($_GET["error"] == "invalidEmail"){
						echo "<p>Choose a proper email!</p>";
					}
					else if($_GET["error"] == "passworddontmatch"){
						echo "<p>Passwords doesn't match!</p>";
					}
					else if($_GET["error"] == "Usernametaken"){
						echo "<p>Username is already taken!</p>";
					}
					else if($_GET["error"] == "none"){
						echo "<p>You have signed up!</p>";
					}
				}
			 ?>