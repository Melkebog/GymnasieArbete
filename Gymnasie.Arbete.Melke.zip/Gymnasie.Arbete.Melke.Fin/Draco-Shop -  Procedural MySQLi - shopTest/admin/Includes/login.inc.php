<?php
    
	if(isset($_POST["submit"])){
		$name = $_POST["uid"];
		$password = $_POST["pwd"];
		
		require_once 'dbh.inc.php';
		require_once 'functions.inc.php';
		
		if(emptyInputLogin($name, $password) !== false){
		   header("location: ../index.php?error=emptyinput");
		   exit();
		}
		
		loginAdmin($conn, $name, $password);
	}
	else{
		header("location: ../index.php?error=emptyinput");
		exit();
	}