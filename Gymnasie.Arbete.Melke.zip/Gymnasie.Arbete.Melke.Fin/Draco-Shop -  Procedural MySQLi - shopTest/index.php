<?php
   include 'DBhandler.background.php';
   session_start();
?>



<!DOCTYPE html>
<html>
<head>
       <meta charset="utf-8" />                                                                               
	   <title>Draco Store</title>
	   <meta name="viewport" content="with=device-width, initial-scale=1.0">
	   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <link rel="stylesheet" href="style.css" />
	   <link rel="preconnect" href="https://fonts.googleapis.com">
       <link rel="preconnect" href="https://fonts.gstatic.com">
       <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	   <script src="https://kit.fontawesome.com/14cfa882fd.js" crossorigin="anonymous"></script>
	   
	   

</head> 
<body> 
 <script type="text/javascript">
    var alerted = localStorage.getItem('alerted') || '';
    if (alerted != 'yes') {
     alert("This Webpage is not real and only used for academic purposes, No purchase is valid and Wont charge or deliver said product");
     localStorage.setItem('alerted','yes');
    }
</script>
<div class="header">
  <div class="container">
   
     <div class="navbar">
	       	       <!-------Login User-------->
	   
		<nav>
		     <ul id="MenuItems">
			    <li><a href="">Home</a></li>
				<li><a href="#prod">Product</a></li>
				<li><a href="#footer">About</a></li>
				<li><a href="#footer">Contact</a></li>
			 </ul>
		</nav>
		<a href="cart.php"><img src="images/cart2.png" width="30px" height="30px" text="white"><span id="cart-item" class="badge badge-warning"></span></a>
		<img src="images/menu2.png" class="menu-icon" onclick="menutoggle()">
		
	 </div>
	  <?php include "Login_stuff.inc.php"; 
	  ?>
	 
	 <div class="row">
	     <div class="col-2">
		   <h1>Release The beast<br/>within!</h1>
		   <p>Become more, be who you to be within</p>
		   <a href="#prod" class="mockknapp">Explore Now &#10132;</a>
         </div>
		 <div class="col-2">
		    <img src="images/image1.png">
		 </div>
	 </div>
</div>
</div>
<!-------featured categories-------->
   <div class="categories">  
     <div class="small-container">
	  <div class="row">
	    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		  <div class="carousel-inner">
			<div class="carousel-item active">
			  <img class="" src="images/category-1.jpg" alt="First slide">
			</div>
			<div class="carousel-item">
			  <img class="" src="images/category-2.jpg" alt="Second slide">
			</div>
			<div class="carousel-item">
			  <img class="" src="images/category-3.jpg" alt="Third slide">
			</div>
		  </div>
		  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
			<span class="carousel-control-prev-icon" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
			<span class="carousel-control-next-icon" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		  </a>
		</div>
	  </div>
	 </div>
	</div>
<!-------featured products-------->
    <div class="small-container">
	<div id="message"></div>
	   <h2 class="title">Featured Products<h2>
	   <div class="shoprow more" id="prod">
	    <?php include 'ProductsShower.php'
		?>   
	   </div>
	   <button class="loader_btn">Load more</button>
	   </br>
	   <h2 class="title">Latest Products</h2>
	    <div class="shoprow">
	     <?php include 'Productslatest.php'
		?>  
	   </div>
    </div>
	<!---offer--->
	<div id="offer">
	  <div class="small-container">
	  <h2 class="title">Exclusive Deals<h2>
	      <div class="row">
		     <div class="col-2">
			     <img src="images/exclusive.png" class="offer-img">
			 </div>
			 <div class="col-2">
			     <p>Exclusively Available on Drako</p>
				 <h1>Smart band 4</h1>
				 <small>This clock is cool and have nice colors</small>
				 <a href="#prod" class="mockknapp">Buy now &#8594;</a>
			 </div>
          </div>		
	  </div>
	</div>
	<!------brand----->
	<div id="brands">
	  <div class="small-container">
	    <div class="row">
	      <div id="col-5">
		    <img src="Images/DracoLogga.png">
		  </div>
	    </div>
	  </div>
	</div>
	<!------- footer----->
	<div id="footer">
	   <div class="container">
	      <div class="row">
		     <div class="footer-col-1">
			  <h3>Download a app</h3>
			  <p>You can download a app any where</p></br>
			 </div>
			 <div class="footer-col-2">
			  <img src="">
			  <p>We are here for your convenience</p>
			 </div>
			 <div class="footer-col-3">
			  <h3>Useful Links</h3>
			  <ul>
			    <li>Coupons</li>
				<li>Blog post</li>
				<li>Return Policy</li>
				<li><a href="admin/index.php">Admin login</a></li>
			  </ul>
			 </div>
			  <div class="footer-col-4">
			  <h3>Follow Drako</h3>
			  <ul>
			    <li>Facebok</li>
				<li>Twitter</li>
				<li>Instagram</li>
				<li>Youtube</li>
			  </ul>
			 </div>  
		  </div>
		  <hr>
		  <p class="copyright">CopyRight 2022 - Melke Bogdo</p>
	   </div>
	</div>
	<!-------js-------->
	   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        
		<!-- Popper JS -->
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	   <script src="js/loadmoreprod.js"></script>
	   <script src="js/toggle.js"></script>
	   <script src="js/ClickfuctionforLog.js"></script>
	   <script src="js/SenddatatoCart.js"></script>
	  
</body>
</html> 