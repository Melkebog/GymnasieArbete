<?php
		$sql = "SELECT * FROM products ORDER BY id DESC LIMIT 4";
	    $result = mysqli_query($conn, $sql);
	    if (mysqli_num_rows($result) > 0){
		    while($row = mysqli_fetch_assoc($result)){
			    echo "<div id= 'col-4'>".PHP_EOL;
				echo "<img src='Images/";
				echo $row['bild'];
				echo "'>".PHP_EOL;
				echo "<h4>";
				echo $row['title'];
				echo "</h4>".PHP_EOL;
				echo "<p>";
				echo '$ '.$row['price'].'.00';
				echo "</p>".PHP_EOL;
				echo "<div>";
				
				echo "<form action='' class='form-submit'>";
				echo "<input type='hidden' class='pid' value='";
				echo $row['id'];
				echo "'>".PHP_EOL;
				
				
				echo "<input type='hidden' class='pname' value='";
				echo $row['title'];
				echo "'>".PHP_EOL;
				
				echo "<input type='hidden' class='pprice' value='";
				echo $row['price'];
				echo "'>".PHP_EOL;
				
				echo "<input type='hidden' class='pdescription' value='";
				echo $row['description'];
				echo "'>".PHP_EOL;
				
				echo "<input type='hidden' class='pimage' value='";
				echo $row['bild'];
				echo "'>".PHP_EOL;
			
				echo "<input type='hidden' class='pcode' value='";
				echo $row['prodID'];
				echo "'>".PHP_EOL;
				
				echo "<button class='btn btn-success addItemBtn' type='button'>Add cart</button>".PHP_EOL;
				echo "</form>";
				echo "</div>";
				echo "</div>";
				  }
		}else {
		  echo "There are no products";
	     }
		  
		?>   