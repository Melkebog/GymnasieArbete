 <?php 
   session_start();
 ?>
<!DOCTYPE html>
<html>
<head>
       <meta charset="utf-8" />                                                                               
	   <title>Admin Log in form</title>
       <meta name="viewport" content="with=device-width, initial-scale=1.0">
       <link rel="stylesheet" href="Admin_css/Adminformstyle.css" />
</head> 
<body>
    <div class="containerbox">
     <div class="index-login-login">
	    <h1>Login, Admin</h1>
		<form action="Includes/login.inc.php" method="post">
		    <div class="txt_field">
			    <input type="text" name="uid">
				<label>Username</label>
			</div>
			<div class="txt_field">
			    <input type="password" name="pwd">
				<label>Password</label>
			</div>
			<div class="pass">Forgot password</div>
			<input type="submit" name="submit" value="Login">
			<div class="go_back_link">
			    Go back? <a href="../index.PHP">Back to main</a>
			</div>
		</form>
	 </div>
    </div>	 
</body>
</html> 
