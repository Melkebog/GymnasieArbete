<?php
  require 'config.php';
  session_start();
  
  $grand_total = 0;
  $allItems = '';
  $items = array();
  
  $sql = "SELECT CONCAT(product_name, '(',qty,')') AS ItemQty, total_price FROM cart";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $result = $stmt->get_result();
  while($row = $result->fetch_assoc()){
	  $grand_total +=$row['total_price'];
	  $items[] = $row['ItemQty'];
  }
  $allItems = implode(", ", $items);
?>
<!DOCTYPE html>
<html>
<head>
       <meta charset="utf-8" />                                                                               
	   <title>Draco Store</title>
	   <meta name="viewport" content="with=device-width, initial-scale=1.0">
	   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <link rel="stylesheet" href="style.css" />
	   <link rel="preconnect" href="https://fonts.googleapis.com">
       <link rel="preconnect" href="https://fonts.gstatic.com">
       <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
	   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	   <script src="https://kit.fontawesome.com/14cfa882fd.js" crossorigin="anonymous"></script>
</head> 
<body> 
<div class="header">
	  <div class="container">
		  <?php
		  if(isset($_SESSION["useruid"]))
		  {
		?>
			   <div class='design_Name'><h1><?php echo "Hi, ".$_SESSION["useruid"];?><h1></div>
		<?php
		  }
		  else {
			  header("location: index.php");
		  }
		?>
		<a href="index.php"><img src="images/cart2.png" width="30px" height="30px" text="white"><span id="cart-item" class="badge badge-warning">Return to start</span></a>
		
		<div class= "row justify-content-center">
			<div class="col-lg-6 px-4 pb-4" id="order">
				<h4 class="text-center text-white p-2">Complete order</h4>
				<div class="jumbotron p-3 mb-2 text-center">
				<h6 class="lead"><b>Product(s) :<b> <?= $allItems; ?></h6>
				<h6 class="lead"><b>Delviery Charge :<b> Free</h6>
				<h5 class="lead"><b>Total Amount to pay :<b> $ <?= number_format($grand_total,2) ?></h5>
				</div>
				<form action="" method="post" id="placeOrder">
					<Input type="hidden" name="products" value="<?= $allItems; ?>">
					<Input type="hidden" id="total1" name="grand_total" value="<?= $grand_total; ?>">
					<div class="form-group">
						<input type="text" name="name" value="<?= $_SESSION['useruid'] ?>" class="form-control" placeholder="Enter Name" required>
					</div>
					<div class="form-group">
						<input type="email" name="email" value="<?= $_SESSION['useremail'] ?>" class="form-control" placeholder="Enter E-mail" required>
					</div>
					<div class="form-group">
						<input type="tel" name="phone" class="form-control" placeholder="Enter Phone" required>
					</div>
					<div class="form-group">
						<textarea name="address" class="form-control" rows="3" cols="10" placeholder="Enter Delivery Address Here..."></textarea>
					</div>
					<h6 class="text-center lead text-white p-2">Select Payment Mode</h6>
					<div class="form-group">
						<select name="pmode" class="form-control" required>
							<option value="" selected disabled>-Select Payment Mode</option>
							<option value="Cash">Cash On Delivery</option>
							<option value="netBanking">Net Banking</option>
							<option value="card">Credit card</option>
						</select>
					</div>
					<div class="form-group">
						<input type="submit" name="submit" value="place Order" id="myButton" class="btn btn-danger btn-block" <?= ($grand_total>1)?'':'disabled'; ?>>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
	<script src="js/completeOrder.js"></script>
</body>
</html> 
