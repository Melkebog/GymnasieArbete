<?php

    

    $mysqli = new mysqli('localhost', 'root', '', 'drako-shopdb') or die(mysqli_error($mysqli));
	
	if (isset($_GET['delete'])){
		$id = $_GET['delete'];
	    $mysqli->query("DELETE FROM orders WHERE id=$id") or die($mysqli->error());
		
	   $_SESSION['message'] = "Record has been Deleted!";
	   $_SESSION['msg_type'] = "Danger";
	   
	   
	   header("location: ../Data_tables/OrdersTable.php");
	}
	
	if (isset($_GET['Print'])){
		$id = $_GET['Print'];
		$update = true;
		$result = $mysqli->query("SELECT * FROM admin WHERE Admin_id=$id") or die($mysqli->error());
		
			$row = $result->fetch_array();
			$Admin_uid = $row['Admin_uid'];
			$Admin_pwd = $row['Admin_pwd'];
			$Admin_email = $row['Admin_email'];

		
	}
	
	if (isset($_POST['update'])){
		$id = $_POST['Admin_id'];
		$Admin_uid = mysqli_real_escape_string($mysqli, $_POST['Admin_uid']);
		$Admin_pwd = mysqli_real_escape_string($mysqli, $_POST['Admin_pwd']);
		$Admin_email = mysqli_real_escape_string($mysqli, $_POST['Admin_email']);
		
		$mysqli->query("UPDATE admin SET Admin_uid='$Admin_uid', Admin_pwd='$Admin_pwd', Admin_email='$Admin_email' 
		WHERE Admin_id='$id'") or die($mysqli->error);
		
		$_SESSION['message'] = "Record has been Updated!";
		$_SESSION['msg_type'] = "warning";
		
		header("location: ../Data_tables/Admintable.php");
	}
?>