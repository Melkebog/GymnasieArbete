<?php

   

    $mysqli = new mysqli('localhost', 'root', '', 'drako-shopdb') or die(mysqli_error($mysqli));
	$id = 0;
	$update = false;
	$title = '';
	$price = '';
	$description = '';
	$bild = '';
	$prodID = '';
	if(isset($_POST['save']) && isset($_FILES['bild'])){
	   $title = mysqli_real_escape_string($mysqli, $_POST['title']);
	   $price = mysqli_real_escape_string($mysqli, $_POST['price']);
	   $description = mysqli_real_escape_string($mysqli, $_POST['description']);
	   $prodID = mysqli_real_escape_string($mysqli, $_POST['prodID']);
	   $bild = mysqli_real_escape_string($mysqli, $_POST['bild']);
	   
	   $file = $_FILES['bild'];
		
		$filename = $_FILES['bild']['name'];
		@$fileTmpname = $_FILES['bild']['tmp_name'];
		@$fileSize = $_FILES['bild']['size'];
		@$fileError = $_FILES['bild']['error'];
		@$fileType = $_FILES['bild']['type'];
		
		$fileExt = explode('.', $filename);
		$fileActualExt = strtolower(end($fileExt));
		
		$allowed = array('jpg', 'jpeg', 'png');
		
		if(in_array($fileActualExt, $allowed)){
			if($fileError === 0){
				if($fileSize < 1000000){
					$fileNameNew = uniqid('', true).".".$fileActualExt;
					
					$filDestination = '../../Images/'.$fileNameNew;
					move_uploaded_file($fileTmpname, $filDestination);
				}else{
					echo 'Your file is to big!';
				}
					
			}else{
				echo "There was a error uploading this file!";
			}
		}
		else{
			echo "You cant upload this fyle type!";
		}

	  
	   $mysqli->query("INSERT INTO products (title, price, description, bild, prodID) VALUES('$title', '$price', '$description', '$fileNameNew', '$prodID')") or
	       die($mysqli->error);
	    
	   $_SESSION['message'] = "Record has been saved!";
	   $_SESSION['msg_type'] = "Sucess";
	   
	   header("location: ../Data_tables/TableforproductEditor.PHP");

	}
	
   
	
	
	
	
	if (isset($_GET['delete'])){
		$id = $_GET['delete'];
		$res = $mysqli->query("select bild FROM products WHERE id=$id") or die($mysqli->error());
		$r = $res->fetch_array();
		$path = '../Images/'.$r[0];
		unlink($path);
	    $mysqli->query("DELETE FROM products WHERE id=$id") or die($mysqli->error());
		
	   $_SESSION['message'] = "Record has been Deleted!";
	   $_SESSION['msg_type'] = "Danger";
	   
	   
	   header("location: ../Data_tables/TableforproductEditor.PHP");
	}
	
	if (isset($_GET['edit'])){
		$id = $_GET['edit'];
		$update = true;
		$result = $mysqli->query("SELECT * FROM products WHERE id='$id'") or die($mysqli->error());
		
			$row = $result->fetch_array();
			$title = $row['title'];
			$price = $row['price'];
			$description = $row['description'];
			$bild = $row['bild'];
		
	}
	
	if (isset($_POST['update'])){
		$id = mysqli_real_escape_string($mysqli, $_POST['id']);
		$title = mysqli_real_escape_string($mysqli, $_POST['title']);
		$price = mysqli_real_escape_string($mysqli, $_POST['price']);
		$description = mysqli_real_escape_string($mysqli, $_POST['description']);
		$bild = mysqli_real_escape_string($mysqli, $_POST['bild']);
		
		$mysqli->query("UPDATE products SET title='$name', price='$price', description='$description', 
		bild='$bild' WHERE id='$id'") or die($mysqli->error);
		
		$_SESSION['message'] = "Record has been Updated!";
		$_SESSION['msg_type'] = "warning";
		
		header("location: ../Data_tables/TableforproductEditor.PHP");
	}
?>