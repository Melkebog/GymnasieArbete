<?php

    

    $mysqli = new mysqli('localhost', 'root', '', 'drako-shopdb') or die(mysqli_error($mysqli));
	$id = 0;
	$update = false;
	$Admin_uid = '';
	$Admin_pwd = '';
	$Admin_email = '';
	
	if(isset($_POST['save'])){
		//protect from injections when on Procedural and not oop
	   $Admin_uid = mysqli_real_escape_string($mysqli, $_POST['Admin_uid']);
	   $Admin_pwd = mysqli_real_escape_string($mysqli, $_POST['Admin_pwd']);
	   $Admin_email = mysqli_real_escape_string($mysqli, $_POST['Admin_email']);
	   
	   //hash pwd to do
	   $hash = password_hash($Admin_pwd, PASSWORD_DEFAULT);
	   
	   $mysqli->query("INSERT INTO admin (Admin_uid, Admin_pwd, Admin_email) VALUES('$Admin_uid', '$hash', '$Admin_email')") or
	       die($mysqli->error);
	    
	   $_SESSION['message'] = "Record has been saved!";
	   $_SESSION['msg_type'] = "Sucess";
	   
	   header("location: ../Data_tables/Admintable.php");

	}
	
   
	
	
	
	
	if (isset($_GET['delete'])){
		$id = $_GET['delete'];
	    $mysqli->query("DELETE FROM admin WHERE Admin_id=$id") or die($mysqli->error());
		
	   $_SESSION['message'] = "Record has been Deleted!";
	   $_SESSION['msg_type'] = "Danger";
	   
	   
	   header("location: ../Data_tables/Admintable.php");
	}
	
	if (isset($_GET['edit'])){
		$id = $_GET['edit'];
		$update = true;
		$result = $mysqli->query("SELECT * FROM admin WHERE Admin_id=$id") or die($mysqli->error());
		
			$row = $result->fetch_array();
			$Admin_uid = $row['Admin_uid'];
			$Admin_pwd = $row['Admin_pwd'];
			$Admin_email = $row['Admin_email'];

		
	}
	
	if (isset($_POST['update'])){
		$id = $_POST['Admin_id'];
		$Admin_uid = mysqli_real_escape_string($mysqli, $_POST['Admin_uid']);
		$Admin_pwd = mysqli_real_escape_string($mysqli, $_POST['Admin_pwd']);
		$Admin_email = mysqli_real_escape_string($mysqli, $_POST['Admin_email']);
		
		$mysqli->query("UPDATE admin SET Admin_uid='$Admin_uid', Admin_pwd='$Admin_pwd', Admin_email='$Admin_email' 
		WHERE Admin_id='$id'") or die($mysqli->error);
		
		$_SESSION['message'] = "Record has been Updated!";
		$_SESSION['msg_type'] = "warning";
		
		header("location: ../Data_tables/Admintable.php");
	}
?>