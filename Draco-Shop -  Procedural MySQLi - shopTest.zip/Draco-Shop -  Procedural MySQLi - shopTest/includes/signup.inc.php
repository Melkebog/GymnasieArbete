<?php
    if(isset($_POST["submit"])){
		
		$uid = $_POST["uid"];
		$email = $_POST["email"];
		$pwd = $_POST["pwd"];
		$pwdrepeat = $_POST["pwdrepeat"];
		
		require_once 'dbh.inc.php';
		require_once 'functions.inc.php';
		
		if(emptyInputSignup($uid, $email, $pwd, $pwdrepeat) !== false){
		   header("location: ../index.php?error=emptyinput");
		   exit();
		}
		if(invalidUid($uid) !== false){
		   header("location: ../index.php?error=invalidUid");
		   exit();
		}
		if(invalidEmail($email) !== false){
		   header("location: ../index.php?error=invalidEmail");
		   exit();
		}
		if(pwdMatch($pwd, $pwdrepeat) !== false){
		   header("location: ../index.php?error=passworddontmatch");
		   exit();
		}
		if(uidExists($conn, $uid, $email) !== false){
		   header("location: ../index.php?error=Usernametaken");
		   exit();
		}
		
		createUser($conn, $uid, $email, $pwd);
	}
	else{
		header("location: ../index.php");
		exit();
	}
