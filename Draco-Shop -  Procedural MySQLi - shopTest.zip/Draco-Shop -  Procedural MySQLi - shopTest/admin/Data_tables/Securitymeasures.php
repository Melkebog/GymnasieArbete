 <?php
 session_start();
 if(!isset($_SESSION['Adminid'])){
	   header("location: ../index.php");
   }
?>
   