
$(document).ready(function(){
	var productcount = 8;
  $("#loader_btn").click(function(){
	  productcount = productcount + 8;
  $(".more").load("getprod.php", {
	   productNewcount: productcount
	});
  });
  
});
	