<div>
     <h1><?php echo "Welcome admin, ".$_SESSION["Adminuid"];?></h1>
	 <a class="btn btn-success" href='../includes/logout.inc.php'>Logout</a>
</div>

<div class="banner">
	   <div class="navbar">
	      <ul>
		      <li><a href="TableforproductEditor.PHP">Products</a></li>
			  <li><a href="Admintable.php">Admin accounts</a></li>
			  <li><a href="UsersAccountTable.php">Costumer account</a></li>
			  <li><a href="OrdersTable.php">Orders</a></li>
		  </ul>
	   </div>
	</div>
	